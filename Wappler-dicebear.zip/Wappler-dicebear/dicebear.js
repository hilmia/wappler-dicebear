const { createAvatar } = require("@dicebear/avatars");
const Sprites = require('@dicebear/avatars-initials-sprites');
const fs = require("fs");

exports.dicebear = function (options) {
    const seed = this.parse(options.seed);

    const svg = createAvatar(Sprites, {
        seed
    });
    fs.writeFileSync(`${options.folder}/${seed.replace(/\s+/g, "_")}.svg`, svg);
    return svg;
}