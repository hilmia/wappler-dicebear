const { createAvatar } = require("@dicebear/avatars");
const Initials = require('@dicebear/avatars-initials-sprites');
const Identicon = require('@dicebear/avatars-identicon-sprites');
const Pixelart = require('@dicebear/pixel-art');
const fs = require("fs");

exports.dicebear = function (options) {
    const seed = this.parse(options.seed);

    const svg = createAvatar(Initials, {
        seed
    });
    fs.writeFileSync(`${options.folder}/${seed.replace(/\s+/g, "_")}.svg`, svg);
    return svg;
}

exports.dicebear_identicon = function (options) {
    const seed = this.parse(options.seed);

    const svg = createAvatar(Identicon, {
        seed
    });
    fs.writeFileSync(`${options.folder}/${seed.replace(/\s+/g, "_")}.svg`, svg);
    return svg;
}

exports.dicebear_pixelart = function (options) {
    const seed = this.parse(options.seed);

    const svg = createAvatar(Pixelart, {
        seed
    });
    fs.writeFileSync(`${options.folder}/${seed.replace(/\s+/g, "_")}.svg`, svg);
    return svg;
}